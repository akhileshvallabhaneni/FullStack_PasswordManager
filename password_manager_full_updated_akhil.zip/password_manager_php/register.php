<?php

require_once 'includes/database.php';

session_start();


//if sessions active send to home
if (isset($_SESSION['user_id'])) {
    header('Location: home');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['fullName'];
    if (empty($full_name) || !isset($full_name) || $full_name === '' || strlen($full_name) < 1 || strlen($full_name) > 255) {
        $error = "Full Name is required.";
    }

    $phone_number = $_POST['phoneNumber'];
    if (empty($phone_number) || !isset($phone_number) || $phone_number === '' || strlen($phone_number) < 1 || strlen($phone_number) > 255) {
        $error = "Phone Number is required.";
    }

    $email = $_POST['email'];
    if (empty($email) || !isset($email) || $email === '' || strlen($email) < 1 || strlen($email) > 255) {
        $error = "Email is required.";
    }


    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    if (empty($password) || !isset($password) || $password === '' || strlen($password) < 6 || strlen($password) > 255) {
        $error = "Password is required. Password must be at least 6 characters.";
    }



    if ($password !== $confirmPassword) {
        $error = "Password and Confirm Password do not match.";
    } 

    if ($error === '') {
        //check if email exists
        $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = :email");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $error = "Email already exists.";
        }else{
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO `users` (`full_name`, `phone_number`, `email`, `password`) VALUES (:full_name, :phone_number, :email, :password);");
            $result = $stmt->execute(['full_name' => $full_name, 'phone_number' => $phone_number, 'email' => $email, 'password' => $hashedPassword]);
            if ($result) {
                $success = "Account created successfully. You will be redirected to login page in 5 seconds. Click <a href='login'>here</a> if you are not redirected.";
            } else {
                $error = "An error occurred.";
            }
        }
    }

    
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePass - Register</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const togglePassword = document.querySelector('#togglePassword');
            const toggleConfirmPassword = document.querySelector('#toggleConfirmPassword');
            const password = document.querySelector('#password');
            const confirmPassword = document.querySelector('#confirmPassword');
            const form = document.querySelector('form');
            
            togglePassword.addEventListener('click', function() {
                const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                password.setAttribute('type', type);
                this.classList.toggle('fa-eye-slash');
            });

            toggleConfirmPassword.addEventListener('click', function() {
                const type = confirmPassword.getAttribute('type') === 'password' ? 'text' : 'password';
                confirmPassword.setAttribute('type', type);
                this.classList.toggle('fa-eye-slash');
            });
            
        });

    </script>
</head>
<body class="bg-[#121417] text-white flex items-center justify-center h-screen">
    <div class="max-w-md w-full bg-[#16181B] p-8 rounded-lg">
        <div class="text-center mb-8">
            <i class="fas fa-user-secret text-[#2563eb] text-6xl"></i>
            <h2 class="text-3xl font-bold mt-2">Register for SecurePass</h2>
        </div>

        <?php
        
        if ($error) {
            echo "<div class='bg-red-500 text-white p-3 mb-4 rounded'>$error</div>";
        }

        if ($success) {
            echo "<div class='bg-green-500 text-white p-3 mb-4 rounded'>$success</div>";
            header("refresh:5;url=login");
        }

        ?>

        <form action="/register" method="POST" enctype="application/x-www-form-urlencoded">
            <div class="mb-4">
                <label for="fullName" class="block text-sm font-bold mb-2">Full Name</label>
                <input type="text" id="fullName" name="fullName" class="w-full px-3 py-2 rounded-lg bg-[#121417] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50" required>
            </div>
            <div class="mb-4">
                <label for="phoneNumber" class="block text-sm font-bold mb-2">Phone Number</label>
                <input type="tel" id="phoneNumber" name="phoneNumber" class="w-full px-3 py-2 rounded-lg bg-[#121417] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50" required>
            </div>
            <div class="mb-4">
                <label for="email" class="block text-sm font-bold mb-2">Email</label>
                <input type="email" id="email" name="email" class="w-full px-3 py-2 rounded-lg bg-[#121417] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50" required>
            </div>
            <div class="mb-4 relative">
                <label for="password" class="block text-sm font-bold mb-2">Password</label>
                <input type="password" id="password" name="password" class="w-full px-3 py-2 rounded-lg bg-[#121417] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50 pr-10" required>
                <i id="togglePassword" class="fas fa-eye cursor-pointer absolute right-3 top-10 text-[#2563eb]"></i>
            </div>
            <div class="mb-6 relative">
                <label for="confirmPassword" class="block text-sm font-bold mb-2">Confirm Password</label>
                <input type="password" id="confirmPassword" name="confirmPassword" class="w-full px-3 py-2 rounded-lg bg-[#121417] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50 pr-10" required>
                <i id="toggleConfirmPassword" class="fas fa-eye cursor-pointer absolute right-3 top-10 text-[#2563eb]"></i>
            </div>
            <div>
                <button type="submit" class="w-full bg-[#2563eb] py-2 px-4 rounded hover:bg-blue-700 transition duration-300">Register</button>
            </div>
        </form>
        <div class="text-center mt-4">
            <a href="login" class="hover:text-[#2563eb] transition duration-300">Already have an account? Login</a>
        </div>
    </div>
</body>
</html>
