<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePass - Home</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .dropdown:hover .dropdown-menu {
            display: block;
        }
        .notification {
            background-color: #16181B;
            color: #fff;
        }
        .icon-box {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .icon-box i {
            font-size: 2rem;
        }
    </style>
</head>
<body class="bg-[#121417] text-white">
    <nav class="border-b border-[#16181B] py-4">
        <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <div class="flex items-center">
                <i class="fas fa-user-secret text-[#2563eb] mr-2"></i>
                <span class="font-semibold">SecurePass</span>
            </div>
            <div class="flex-grow flex justify-center items-center space-x-4">
                <a href="/home" class="hover:text-[#2563eb]">Home</a>
                <a href="#features" class="hover:text-[#2563eb]">Features</a>
                <a href="#pricing" class="hover:text-[#2563eb]">Pricing</a>
            </div>
            <a href="/login" class="bg-[#2563eb] text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300">Login</a>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="text-center py-20">
        <h1 class="text-5xl font-bold">Keep Your Passwords Safe and Secure</h1>
        <p class="mt-4 text-xl">SecurePass offers top-notch security for your digital life, ensuring your passwords are safe, encrypted, and accessible only by you.</p>
        <a href="#features" class="mt-8 inline-block bg-[#2563eb] text-white py-3 px-6 rounded hover:bg-blue-700 transition duration-300">Learn More</a>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-20">
        <div class="max-w-6xl mx-auto px-4">
            <h2 class="text-4xl font-bold text-center">Features</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
                <div class="text-center">
                    <i class="fas fa-shield-alt text-6xl text-[#2563eb]"></i>
                    <h3 class="mt-4 font-bold text-xl">Advanced Encryption</h3>
                    <p class="mt-2">Your passwords are protected with Advanced Encryption, the same encryption standard used by governments and industries.</p>
                </div>
                <div class="text-center">
                    <i class="fas fa-sync-alt text-6xl text-[#2563eb]"></i>
                    <h3 class="mt-4 font-bold text-xl">Seamless Sync</h3>
                    <p class="mt-2">Access your passwords from any device, anywhere, at any time, without compromising on security.</p>
                </div>
                <div class="text-center">
                    <i class="fas fa-user-friends text-6xl text-[#2563eb]"></i>
                    <h3 class="mt-4 font-bold text-xl">Easy Sharing</h3>
                    <p class="mt-2">Safely share your passwords with family or team members without exposing the actual credentials.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
<section id="pricing" class="py-20 bg-[#16181B]">
    <div class="text-center">
        <h2 class="text-4xl font-bold">Simple, Transparent Pricing</h2>
        <p class="mt-4">No hidden fees. Choose the plan that works best for you.</p>
    </div>
    <div class="max-w-4xl mx-auto mt-10">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="bg-[#121417] p-6 rounded-lg text-center">
                <h3 class="font-bold text-xl">Free</h3>
                <p class="mt-2">For individual use</p>
                <ul class="mt-4 text-left">
                    <li><i class="fas fa-circle-check text-[#2563eb]"></i> 50 Passwords</li>
                    <li><i class="fas fa-circle-check text-[#2563eb]"></i> 1 Device Sync</li>
                    <li><i class="fas fa-circle-check text-[#2563eb]"></i> Basic Support</li>
                </ul>
                <a href="/register" class="mt-8 inline-block bg-[#2563eb] text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300">Get Started</a>
            </div>
            <div class="bg-[#121417] p-6 rounded-lg text-center">
                <h3 class="font-bold text-xl">Premium</h3>
                <p class="mt-2">For power users</p>
                <ul class="mt-4 text-left">
                    <li><i class="fas fa-circle-check text-[#2563eb]"></i> Unlimited Passwords</li>
                    <li><i class="fas fa-circle-check text-[#2563eb]"></i> Unlimited Devices</li>
                    <li><i class="fas fa-circle-check text-[#2563eb]"></i> Priority Support</li>
                </ul>
                <a href="/register" class="mt-8 inline-block bg-[#2563eb] text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300">Subscribe</a>
            </div>
            <div class="bg-[#121417] p-6 rounded-lg text-center">
                <h3 class="font-bold text-xl">Family/Team</h3>
                <p class="mt-2">For groups and families</p>
                <ul class="mt-4 text-left">
                    <li><i class="fas fa-circle-check text-[#2563eb]"></i> Unlimited Passwords</li>
                    <li><i class="fas fa-circle-check text-[#2563eb]"></i> Unlimited Devices</li>
                    <li><i class="fas fa-circle-check text-[#2563eb]"></i> Shared Access for up to 6</li>
                </ul>
                <a href="/register" class="mt-8 inline-block bg-[#2563eb] text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300">Get Started</a>
            </div>
        </div>
    </div>
</section>


    <footer class="border-t border-[#16181B] py-4">
        <div class="max-w-7xl mx-auto px-4 text-center">
            SecurePass © 2024. All rights reserved.
        </div>
    </footer>
</body>
</html>
