<?php

require_once 'includes/database.php';

session_start();


//if sessions active send to home
if (!isset($_SESSION['user_id'])) {
    header('Location: login');
    exit();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($_POST['action'] === 'update_password') {
        $oldPassword = $_POST['old_pass'];
        if (empty($oldPassword) || !isset($oldPassword) || $oldPassword === '' || strlen($oldPassword) < 6 || strlen($oldPassword) > 255) {
            $error = "Old Password is required. Password must be at least 6 characters.";
        }

        $newPassword = $_POST['new_pass'];
        if (empty($newPassword) || !isset($newPassword) || $newPassword === '' || strlen($newPassword) < 6 || strlen($newPassword) > 255) {
            $error = "New Password is required. Password must be at least 6 characters.";
        }

        $confirmPassword = $_POST['confirm_pass'];
        if (empty($confirmPassword) || !isset($confirmPassword) || $confirmPassword === '' || strlen($confirmPassword) < 6 || strlen($confirmPassword) > 255) {
            $error = "Confirm Password is required. Password must be at least 6 characters.";
        }

        if ($newPassword !== $confirmPassword) {
            $error = "New Password and Confirm Password do not match.";
        }

        if ($error === '') {
            $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = :email");
            $stmt->execute(['email' => $_SESSION['email']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                if (password_verify($oldPassword, $user['password'])) {
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE `users` SET `password` = :password WHERE `email` = :email");
                    $result = $stmt->execute(['password' => $hashedPassword, 'email' => $_SESSION['email']]);
                    if ($result) {
                        $success = "Password updated successfully.";
                    } else {
                        $error = "Error updating password.";
                    }
                } else {
                    $error = "Invalid old password.";
                }
            } else {
                $error = "Invalid email.";
            }
        }
    }

    if ($_POST['action'] === 'update_settings') {

        $fullName = $_POST['fullName'];
        if (empty($fullName) || !isset($fullName) || $fullName === '' || strlen($fullName) < 1 || strlen($fullName) > 255) {
            $error = "Full Name is required.";
        }

        $phoneNumber = $_POST['phoneNumber'];
        if (empty($phoneNumber) || !isset($phoneNumber) || $phoneNumber === '' || strlen($phoneNumber) < 1 || strlen($phoneNumber) > 16) {
            $error = "Phone Number is required.";
        }


        if ($error === '') {
            $stmt = $pdo->prepare("UPDATE `users` SET `full_name` = :full_name, `phone_number` = :phone_number WHERE `email` = :email");
            $result = $stmt->execute(['full_name' => $fullName, 'phone_number' => $phoneNumber, 'email' => $_SESSION['email']]);
            if ($result) {
                $success = "Account settings updated successfully.";
            } else {
                $error = "Error updating account settings.";
            }
        }
    }
}



?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SecurePass - Account Settings</title>
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body class="bg-[#121417] text-white">
    <nav class="border-b border-[#16181B] py-4">
      <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
        <div class="flex items-center">
          <i class="fas fa-user-secret text-[#2563eb] mr-2"></i>
          <span class="font-semibold">SecurePass</span>
        </div>
        <div class="flex-grow flex justify-center items-center space-x-4">
          <a href="home" class="hover:text-[#2563eb]">Home</a>
          <a href="vault" class="hover:text-[#2563eb]">Vault</a>
          <a href="settings" class="hover:text-[#2563eb]">Settings</a>
        </div>
        <a
          href="logout"
          class="bg-[#2563eb] text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300"
          >Logout</a
        >
      </div>
    </nav>

    <!-- Settings Form -->
    <div class="max-w-4xl mx-auto px-4 mt-10">
      <h1 class="text-3xl font-bold">Account Settings</h1>
        <?php if ($error): ?>
            <div class="bg-red-500 text-white p-3 mb-4 rounded"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="bg-green-500 text-white p-3 mb-4 rounded"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php
        
        $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = :email");
        $stmt->execute(['email' => $_SESSION['email']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);


        ?>

      <form
        class="mt-8"
        action="/settings"
        method="post"
      >
        <input type="text" name="action" value="update_settings" hidden>
        <div class="mb-6">
          <label for="firstName" class="block text-sm font-bold mb-2"
            >First Name</label
          >
          <input
            type="text"
            id="firstName"
            name="fullName"
            class="w-full px-3 py-2 rounded bg-[#16181B] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50"
            value="<?php echo $user['full_name']; ?>"
          />
        </div>
        <div class="mb-6">
          <label for="email" class="block text-sm font-bold mb-2">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            readonly
            class="w-full px-3 py-2 rounded bg-[#16181B] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50"
            value="<?php echo $user['email']; ?>"
          />
        </div>
        <div class="mb-6">
          <label for="phoneNumber" class="block text-sm font-bold mb-2"
            >Phone Number</label
          >
          <input
            type="tel"
            id="phoneNumber"
            name="phoneNumber"
            class="w-full px-3 py-2 rounded bg-[#16181B] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50"
            value="<?php echo $user['phone_number']; ?>"
          />
        </div>
        <div class="mb-6">
          <button
            type="submit"
            class="bg-[#2563eb] py-2 px-4 rounded hover:bg-blue-700 transition duration-300"
          >
            Update Settings
          </button>
        </div>
      </form>




    <form class="mt-8" action="/settings" method="post" >
        <input type="text" name="action" value="update_password" hidden>
        <div class="mb-6">
          <label for="old_pass" class="block text-sm font-bold mb-2">Old Password</label>
          <input
            type="password"
            id="old_pass"
            name="old_pass"
            class="w-full px-3 py-2 rounded bg-[#16181B] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50"
            placeholder="Old Password"

        
          />
        </div>

        <div class="mb-6">
          <label for="new_pass" class="block text-sm font-bold mb-2">New Password</label>
          <input
            type="password"
            id="new_pass"
            name="new_pass"
            class="w-full px-3 py-2 rounded bg-[#16181B] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50"
            placeholder="New Password"
          />

        </div>

        <div class="mb-6">
          <label for="confirm_pass" class="block text
            -sm font-bold mb-2">Confirm Password</label>
            <input
            type="password"
            id="confirm_pass"
            name="confirm_pass"
            class="w-full px-3 py-2 rounded bg-[#16181B] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50"
            placeholder="Confirm Password"
            />
        </div>



        <div class="mb-6">
          <button
            type="submit"
            class="bg-[#2563eb] py-2 px-4 rounded hover:bg-blue-700 transition duration-300"
          >
            Update Password
          </button>
        </div>
      </form>
    </div>

    <footer class="border-t border-[#16181B] py-4">
      <div class="max-w-7xl mx-auto px-4 text-center">
        SecurePass © 2024. All rights reserved.
      </div>
    </footer>

  </body>
</html>
