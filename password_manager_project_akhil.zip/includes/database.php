<?php


$pdo = new PDO("mysql:host=localhost;dbname=pass_mngr", "admin", "6xC12m1FlGAndjyaNtMrlDD");

// Check connection
if($pdo === false){
    die("ERROR: Could not connect. " . $conn->connect_error);
}
?>