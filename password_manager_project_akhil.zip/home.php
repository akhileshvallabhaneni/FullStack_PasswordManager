<?php

require_once 'includes/database.php';

session_start();


//if sessions active send to home
if (!isset($_SESSION['user_id'])) {
    header('Location: login');
    exit();
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePass - Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-[#121417] text-white">
    <nav class="border-b border-[#16181B] py-4">
        <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <div class="flex items-center">
                <i class="fas fa-user-secret text-[#2563eb] mr-2"></i>
                <span class="font-semibold">SecurePass</span>
            </div>
            <div class="flex-grow flex justify-center items-center space-x-4">
                <a href="home" class="hover:text-[#2563eb]">Home</a>
                <a href="vault" class="hover:text-[#2563eb]">Vault</a>
                <a href="settings" class="hover:text-[#2563eb]">Settings</a>
            </div>
            <a href="logout" class="bg-[#2563eb] text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300">Logout</a>
        </div>
    </nav>

    <!-- Dashboard Main Content -->
    <section class="py-20">
        <div class="max-w-6xl mx-auto px-4">
            <h1 class="text-4xl font-bold text-center">Dashboard Overview</h1>
            <div class="flex justify-between items-center mt-10">
                <!-- Total Passwords Box -->
                <div class="w-1/2 mr-2 bg-[#16181B] p-8 rounded-lg flex items-center justify-center">
                    <i class="fas fa-key fa-2x text-[#2563eb]"></i>
                    <div class="ml-4">
                        <p class="text-xl font-semibold">Total Passwords</p>
                        <p class="text-2xl" id="total-passwords"><?php
                        
                        $stmt = $pdo->prepare("SELECT COUNT(*) AS total_passwords FROM `passwords` WHERE `user_id` = :user_id");    
                        $stmt->execute(['user_id' => $_SESSION['user_id']]);
                        $result = $stmt->fetch(PDO::FETCH_ASSOC);
                        echo $result['total_passwords'];


                        ?></p> <!-- Total Passwords -->
                    </div>
                </div>
                <!-- Compromised Passwords Box -->
                <div class="w-1/2 ml-2 bg-[#16181B] p-8 rounded-lg flex items-center justify-center">
                    <i class="fas fa-exclamation-triangle fa-2x text-[#ff0000]"></i>
                    <div class="ml-4">
                        <p class="text-xl font-semibold">Compromised Passwords</p>
                        <p class="text-2xl" id="compromised-passwords">0</p> <!-- Compromised Passwords -->
                    </div>
                </div>
            </div>

            <!-- Split Section for Last Saved Passwords and Password Generator -->
            <div class="flex mt-10">
                <!-- Last Saved Passwords -->
                <div class="w-1/2 mr-4">
                    <h2 class="text-3xl font-semibold">Last Saved Passwords</h2>
                    <ul class="mt-4 last-saved-passwords">
                        <?php
                        
                        $stmt = $pdo->prepare("SELECT * FROM `passwords` WHERE `user_id` = :user_id ORDER BY `id` DESC LIMIT 5");
                        $stmt->execute(['user_id' => $_SESSION['user_id']]);

                        $passwords = $stmt->fetchAll(PDO::FETCH_ASSOC);

                        foreach ($passwords as $password) {
                            echo "<li class='bg-[#16181B] p-4 rounded-lg mb-2 flex justify-between items-center'>
                                <div>
                                    <p class='text-xl font-semibold'>Site: {$password['site']}</p>
                                    <p class='text-sm'>Username: {$password['username']}</p>
                                </div>
                                <div>
                                    <a href='vault' class='text-[#2563eb] hover:underline'>View</a>
                                </div>
                            </li>";
                        }

                        ?>
                    </ul>
                </div>
                

                 <!-- Password Generator Section -->
    <div class="w-1/2 ml-4 bg-[#16181B] p-8 rounded-lg">
        <h2 class="text-3xl font-semibold">Password Generator</h2>
        <form id="passwordForm" class="mt-4">
            <div>
                <label class="inline-flex items-center mt-3">
                    <input type="checkbox" id="includeNumbers" class="form-checkbox h-5 w-5 text-blue-600"><span class="ml-2 text-white">Include Numbers</span>
                </label>
            </div>
            <div>
                <label class="inline-flex items-center mt-3">
                    <input type="checkbox" id="includeSymbols" class="form-checkbox h-5 w-5 text-blue-600"><span class="ml-2 text-white">Include Symbols</span>
                </label>
            </div>
            <div>
                <label class="inline-flex items-center mt-3">
                    <input type="checkbox" id="includeUppercase" class="form-checkbox h-5 w-5 text-blue-600"><span class="ml-2 text-white">Include Uppercase Letters</span>
                </label>
            </div>
            <div class="mt-4">
                <label for="password-length" class="block text-sm font-bold mb-2">Password Length:</label>
                <input type="range" min="4" max="20" value="12" class="slider" id="password-length">
                <span id="length-display">12</span> Characters
            </div>
            <div class="mt-4">
                <button type="button" onclick="generatePassword()" class="bg-[#2563eb] text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300">Generate Password</button>
            </div>
        </form>
        <div class="mt-4">
            <input type="text" id="generatedPassword" oninput="evaluateStrength(this.value)" class="w-full p-2 bg-[#121417] border border-gray-700 rounded">
            <div id="strengthScore" class="h-2 bg-gray-200 rounded mt-2">
                <div id="strengthBar" class="h-2 bg-green-500 rounded" style="width: 0%"></div>
            </div>
        </div>
    </div>

    <!-- Script for Password Generation and Strength Evaluation -->
    <script>
        function generatePassword() {
            const length = document.getElementById('password-length').value;
            const includeNumbers = document.getElementById('includeNumbers').checked;
            const includeSymbols = document.getElementById('includeSymbols').checked;
            const includeUppercase = document.getElementById('includeUppercase').checked;
            const charset = "abcdefghijklmnopqrstuvwxyz" + 
                            (includeNumbers ? "0123456789" : "") + 
                            (includeSymbols ? "!@#$%^&*(){}[]-_=+><.,/?:;" : "") + 
                            (includeUppercase ? "ABCDEFGHIJKLMNOPQRSTUVWXYZ" : "");
            let password = "";
            for (let i = 0, n = charset.length; i < length; ++i) {
                password += charset.charAt(Math.floor(Math.random() * n));
            }
            document.getElementById('generatedPassword').value = password;
            evaluateStrength(password);
        }


        function evaluateStrength(password) {
            let score = 0;
            if (password.length > 5) score += 25;
            if (/[0-9]/.test(password)) score += 25;
            if (/[!@#$%^&*]/.test(password)) score += 25;
            if (/[A-Z]/.test(password)) score += 25;
            
            // Update strength score visually
            const strengthBar = document.getElementById('strengthBar');
            strengthBar.style.width = `${score}%`;
            strengthBar.className = 'h-2 rounded';
            if (score < 25) {
                strengthBar.classList.add('bg-red-500');
            } else if (score < 35) {
                strengthBar.classList.add('bg-orange-500');
            } else if (score < 55) {
                strengthBar.classList.add('bg-yellow-500');
            } else {
                strengthBar.classList.add('bg-green-500');
            }
        }
    
       


    </script>
</body>
</html>
