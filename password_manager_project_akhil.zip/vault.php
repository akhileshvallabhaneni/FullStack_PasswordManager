<?php

require_once 'includes/database.php';

session_start();


//if sessions active send to home
if (!isset($_SESSION['user_id'])) {
    header('Location: login');
    exit();
}


$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    if ($action === 'add') {
        $sites = $_POST['site'];
        $usernames = $_POST['username'];
        $passwords = $_POST['password'];

        if (count($sites) !== count($usernames) || count($sites) !== count($passwords)) {
            $error = "Invalid form data.";
        }

        if ($error === '') {
            $stmt = $pdo->prepare("INSERT INTO `passwords` (`user_id`, `site`, `username`, `password`) VALUES (:user_id, :site, :username, :password)");
            foreach ($sites as $index => $site) {
                $result = $stmt->execute(['user_id' => $_SESSION['user_id'], 'site' => $site, 'username' => $usernames[$index], 'password' => $passwords[$index]]);
                if (!$result) {
                    $error = "Error adding password.";
                    break;
                }
            }

            if ($error === '') {
                $success = "Passwords added successfully.";
            }
        }
    }
}


if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM `passwords` WHERE `id` = :id AND `user_id` = :user_id");
    $result = $stmt->execute(['id' => $_GET['id'], 'user_id' => $_SESSION['user_id']]);
    if ($result) {
        $success = "Password deleted successfully.";
    } else {
        $error = "Error deleting password.";
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SecurePass - Vault</title>
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body class="bg-[#121417] text-white">
    <nav class="border-b border-[#16181B] py-4">
        <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <div class="flex items-center">
                <i class="fas fa-user-secret text-[#2563eb] mr-2"></i>
                <span class="font-semibold">SecurePass</span>
            </div>
            <div class="flex-grow flex justify-center items-center space-x-4">
                <a href="home" class="hover:text-[#2563eb]">Home</a>
                <a href="vault" class="hover:text-[#2563eb]">Vault</a>
                <a href="settings" class="hover:text-[#2563eb]">Settings</a>
            </div>
            <a href="logout"
                class="bg-[#2563eb] text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300">Logout</a>
        </div>
    </nav>

    <style>
        /* Style for Add Password Modal */
        #addPasswordModal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            align-items: center;
            justify-content: center;
        }
    </style>

    <!-- Vault Content -->
    <div class="max-w-6xl mx-auto px-4 mt-10">
        <h1 class="text-3xl font-bold">Your Vault</h1>
        <div id="passwordList" class="grid grid-cols-4 gap-4 mt-8">
            <!-- Password entries will be loaded here -->
        </div>

        <?php if ($error): ?>
            <div class="bg-red-500 text-white p-3 mb-4 rounded"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="bg-green-500 text-white p-3 mb-4 rounded"><?php echo $success; ?></div>
        <?php endif; ?>

        <!-- Add New Password Button -->
        <button id="addPassword"
            class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-4">
            Add New
        </button>
        <div class="mb-6">
        <label class="block text-sm font-bold mb-2">Passwords</label>
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-[#16181B]">
                <tr>
                <th scope="col" class="px-6 py-3">#ID</th>
                <th scope="col" class="px-6 py-3">Site</th>
                <th scope="col" class="px-6 py-3">Username</th>
                <th scope="col" class="px-6 py-3">Password</th>
                <th scope="col" class="px-6 py-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                
                $stmt = $pdo->prepare("SELECT * FROM `passwords` WHERE `user_id` = :user_id");
                $stmt->execute(['user_id' => $_SESSION['user_id']]);
                $passwords = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($passwords as $password) {
                    echo "<tr class='bg-[#16181B] border-b border-gray-700'>";
                    echo "<td class='px-6 py-4'>{$password['id']}</td>";
                    echo "<td class='px-6 py-4'>{$password['site']}</td>";
                    echo "<td class='px-6 py-4'>{$password['username']}</td>";
                    echo "<td class='px-6 py-4'>
                        <span class='tagged-password'>
                            <span type='password' class='password-input' value='{$password['password']}'>********</span>
                            <i class='fas fa-eye cursor-pointer text-[#2563eb] ml-2'></i>
                        </span>
                    </td>";
                    echo "<td class='px-6 py-4'>
                            <a href='vault?action=delete&id={$password['id']}' class='text-red-600 hover:text-red-700'>Delete</a>
                        </td>";
                    echo "</tr>";
                }

                ?>
            </tbody>
            </table>
        </div>
        </div>
    </div>

    <script>
    // Event listener to toggle password visibility
    document.querySelectorAll(".tagged-password").forEach(function (element) {
        const passwordInput = element.querySelector(".password-input");
        const eyeIcon = element.querySelector(".fa-eye");

        eyeIcon.addEventListener("click", function () {
            if (passwordInput.innerHTML === "********") {
                passwordInput.innerHTML = passwordInput.getAttribute("value");
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
                
            } else {
                passwordInput.innerHTML = "********";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            }
        });
    });
</script>

    <!-- Add Password Modal -->
    <div id="addPasswordModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden">
        <div class="flex items-center justify-center h-full">
            <div class="bg-[#16181B] p-6 rounded-lg max-w-sm mx-auto">
                
                <form id="addPasswordForm" action="/vault" method="POST">
                    <input type="text" name="action" value="add" hidden />
                    <h2 class="text-xl font-bold text-white mb-4">Add New Password</h2>
                    <div id="passwordFields">
                        <!-- Dynamic password fields -->
                        <div class="password-entry">
                            <div class="mb-4">
                                <label class="text-white">Site URL:</label>
                                <input id="site"
                                    type="text"
                                    name="site[]"
                                    class="w-full p-2 rounded bg-gray-700 text-white"
                                    required
                                />
                            </div>
                            <div class="mb-4">
                                <label class="text-white">Username:</label>
                                <input id="user"
                                    type="text"
                                    name="username[]"
                                    class="w-full p-2 rounded bg-gray-700 text-white"
                                    required
                                />
                            </div>
                            <div class="mb-4">
                                <label class="text-white">Password:</label>
                                <input id="password"
                                    type="password"
                                    name="password[]"
                                    class="w-full p-2 rounded bg-gray-700 text-white"
                                    required
                                />
                            </div>
                        </div>
                    </div>
                    <button type="button" id="addPasswordField"
                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded mb-2">
                        Add Another
                    </button>
                    <br>
                    <button type="submit"
                        class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                        Add Passwords
                    </button>
                    <button type="button" onclick="toggleModal(false)"
                        class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ml-2">
                        Cancel
                    </button>
                </form>
            </div>
        </div>
    </div>

    <footer class="border-t border-[#16181B] py-4">
        <div class="max-w-7xl mx-auto px-4 text-center">
            SecurePass © 2024. All rights reserved.
        </div>
    </footer>

    <script>
        // Helper function to create a new password entry
        function createPasswordEntry() {
            const passwordEntry = document.createElement("div");
            passwordEntry.className = "password-entry";
            passwordEntry.innerHTML = `
                <div class="mb-4">
                    <label class="text-white">Site URL:</label>
                    <input type="text" name="site[]" class="w-full p-2 rounded bg-gray-700 text-white" required />
                </div>
                <div class="mb-4">
                    <label class="text-white">Username:</label>
                    <input type="text" name="username[]" class="w-full p-2 rounded bg-gray-700 text-white" required />
                </div>
                <div class="mb-4">
                    <label class="text-white">Password:</label>
                    <input type="password" name="password[]" class="w-full p-2 rounded bg-gray-700 text-white" required />
                </div>
            `;
            return passwordEntry;
        }

        // Event listener to add more password fields
        document.getElementById("addPasswordField").addEventListener("click", function () {
            const passwordFields = document.getElementById("passwordFields");
            const newEntry = createPasswordEntry();
            passwordFields.appendChild(newEntry);
        });

        // Function to toggle the visibility of the modal
        function toggleModal(show) {
            const modal = document.getElementById("addPasswordModal");
            modal.style.display = show ? "flex" : "none";
        }

        
        // Event listener to open the Add Password Modal
        document.getElementById("addPassword").addEventListener("click", function () {
            toggleModal(true); // Open the modal when "Add New" is clicked
        });
    </script>
</body>

</html>
