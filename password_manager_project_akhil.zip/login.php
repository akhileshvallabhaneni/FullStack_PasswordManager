<?php

require_once 'includes/database.php';

session_start();


//if sessions active send to home
if (isset($_SESSION['user_id'])) {
    header('Location: home');
    exit();
}


$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    if (empty($email) || !isset($email) || $email === '' || strlen($email) < 1 || strlen($email) > 255) {
        $error = "Email is required.";
    }

    $password = $_POST['password'];
    if (empty($password) || !isset($password) || $password === '' || strlen($password) < 6 || strlen($password) > 255) {
        $error = "Password is required. Password must be at least 6 characters.";
    }

    if ($error === '') {
        $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = :email");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['phone_number'] = $user['phone_number'];

                header('Location: home');
                exit();
            } else {
                $error = "Invalid email or password.";
            }
        } else {
            $error = "Invalid email or password.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePass - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  
</head>
<body class="bg-[#121417] text-white flex items-center justify-center h-screen">
    <div class="max-w-md w-full bg-[#16181B] p-8 rounded-lg">
        <div class="text-center mb-8">
            <i class="fas fa-user-secret text-[#2563eb] text-6xl"></i>
            <h2 class="text-3xl font-bold mt-2">Login to SecurePass</h2>
        </div>
        <?php
        
        if ($error) {
            echo "<div class='bg-red-500 text-white p-3 mb-4 rounded'>$error</div>";
        }

        if ($success) {
            echo "<div class='bg-green-500 text-white p-3 mb-4 rounded'>$success</div>";
            header("refresh:5;url=login");
        }

        ?>
        <form id="loginForm" action="/login" method="POST">
            <div class="mb-4">
                <label for="email" class="block text-sm font-bold mb-2">Email</label>
                <input type="email" id="email" name="email" class="w-full px-3 py-2 rounded-lg bg-[#121417] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50" required>
            </div>
            <div class="mb-4">
                <label for="password" class="block text-sm font-bold mb-2">Password</label>
                <input type="password" id="password" name="password" class="w-full px-3 py-2 rounded-lg bg-[#121417] border border-gray-700 focus:border-[#2563eb] focus:ring focus:ring-[#2563eb] focus:ring-opacity-50" required>
            </div>
            <div class="mb-4 flex justify-between items-center">
                <div>
                    <label class="flex items-center">
                        <input type="checkbox" name="remember" class="text-[#2563eb]">
                        <span class="ml-2">Remember Me</span>
                    </label>
                </div>
            </div>
            <div>
                <button type="submit" class="w-full bg-[#2563eb] py-2 px-4 rounded hover:bg-blue-700 transition duration-300">Login</button>
            </div>
        </form>
        <div class="text-center mt-4">
            <a href="/register" class="hover:text-[#2563eb] transition duration-300">Don't have an account? Register</a>
        </div>
    </div>
</body>
</html>
